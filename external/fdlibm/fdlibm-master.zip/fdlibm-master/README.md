[![Build Status](https://github.com/freemint/fdlibm/actions/workflows/build.yml/badge.svg?branch=master)](https://github.com/freemint/fdlibm/actions) 

Latest snapshot: [Download](https://tho-otto.de/snapshots/fdlibm/fdlibm-latest.tar.bz2)
