# define math_opt_barrier(x) (x)
# define math_force_eval(x) (void)(x)

#if defined(__PUREC__)

#if defined(__HAVE_68881__)

#ifndef __NO_MATH_INLINES


#endif /* __NO_MATH_INLINES */

#endif

#endif
